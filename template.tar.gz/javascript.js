$(document).ready(function() {
    $('form:not(.submitted) input').clearonfocus();
    

    
});